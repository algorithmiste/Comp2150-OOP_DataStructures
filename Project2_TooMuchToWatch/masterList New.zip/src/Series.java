
public class Series extends Media{
	private String seriesLengthType;
	

	public Series(String title, int year, double rating, double length, String seriesLengthType) {
		super(title, year, rating, length);
		this.seriesLengthType = seriesLengthType;
	}
	public String toString() {
		
		String toReturn = " ";
		toReturn += this.title + " (" + this.year + ") |" + this.rating + " stars, " + length + " " + seriesLengthType; // turn length to hours and minutes
		
		return toReturn;
	 }
}
