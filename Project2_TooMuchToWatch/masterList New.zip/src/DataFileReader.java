import java.util.Scanner;
import java.io.*;
import java.util.ArrayList;
// any way to be more efficient here - more methods, etc?
// purpose of class use when no instantiation taking place?
public class DataFileReader {
	private static ArrayList<Media> masterList; 
	
	// make exception for title with no ratings i.e. if no rating, instantiate to 0;
	// idea: open in excel and do checks on title and rating, etc to ensure they exist
	// some titles have double dates i.e (1990) (1990), no date, rating, 
	
	 public static ArrayList<Media> readMediaData(String filePath) throws FileNotFoundException, ArrayIndexOutOfBoundsException, NumberFormatException {	
	    	
	    	Scanner s = null;
	    	try {
	    		s = new Scanner(new FileReader(filePath));
	    	} catch (FileNotFoundException e) {
	    		System.out.println("File not found!");
	    		System.exit(1);
	    	}
	    	
	    	int rows = 0; //, columns = 0;
	    	while (s.hasNextLine()) {
	    		rows++;
	    		s.nextLine();
	    	}
	
			s = new Scanner(new FileReader(filePath));
			masterList = new ArrayList<Media>(rows);
			while (s.hasNextLine()) {
				
				for (int i = 0; i < rows; i++) {
					String line = s.nextLine();
					
					
					/** String[] charsToRemove = {"(", ")", ",", "|", "\\s+"};  // Remove media chars
					for (int k = 0; k < charsToRemove.length; k++) {
						String[] mediaObject = line.split(charsToRemove[k]);
					} */
					
					// Grab data from String line
					
					// TITLE
					String titleSnatch;
					int titleEndIndex; int z;
					for (z = line.length() - 1; line.charAt(z) == '('; z--); 
					titleEndIndex = z - 1;
					titleSnatch = line.substring(0, titleEndIndex);
					
					// YEAR
					int yearSnatch; int yearEndIndex; int yearStartIndex;
					for (yearEndIndex = line.length() - 1; line.charAt(yearEndIndex) == ')'; yearEndIndex--);
					for (yearStartIndex = line.length() - 1; line.charAt(yearStartIndex) == '('; yearStartIndex--);
					
					// to check if a year is present within the parentheses
					boolean yearMatch = false; 
					for (int e = yearStartIndex; line.charAt(e) == ')'; e++) {
						if ((line.charAt(e) >= '0' && line.charAt(e) <= '9')) {
							yearMatch = true;
						}
						else {
							yearMatch = false;
						}
					}
					if (yearMatch) {
						
						yearSnatch =  Integer.parseInt(line.substring(yearStartIndex + 1, yearEndIndex)); // Pseudo-cast string to Int
					}
					else {
						yearSnatch = 0;
					}
					// need to debug instances when no YEAR available (troubleshooting)
					// same for rating, etc.
					
					
					
					// RATING
					double ratingSnatch; // int p; for (p = yearEndIndex; line.charAt(p) >= '0' && line.charAt(p) <= '9'; p++); int tempIndex = p;
					int ratingEndIndex; int ratingStartIndex;
					
					
					// to check if a rating is present within the parentheses
					boolean ratingMatch = false; 
					int comma;
					for (comma = line.length() - 1; line.charAt(comma) == ','; comma--) {}
					if ((line.charAt(comma - 1) != 's')) {
							ratingMatch = false;
						}
					else {
							ratingMatch = true;
					}
					
					if (ratingMatch) {
						for (ratingEndIndex = line.length() - 1; line.substring(ratingEndIndex).contains(" stars"); ratingEndIndex--);
						for (ratingStartIndex = ratingEndIndex - 1; line.charAt(ratingStartIndex) == ' '; ratingStartIndex--);
						ratingSnatch = Double.parseDouble(line.substring(ratingStartIndex + 1, ratingEndIndex));  // Pseudo-cast string to Int
					}
					else {
						ratingSnatch = 0;
					}
					
					// LENGTH
					double lengthSnatch = 0;
					String seriesLengthType = " ";
					boolean seriesMatch = false; boolean movieMatch = false; boolean makeMovieMatch = false;
					int m;
					for (m = line.length() - 1; movieMatch || seriesMatch || m == 0; m--) {//(line.charAt(m) >= '0' && line.charAt(m) <= '9') || (line.charAt(m) == ' '); m--) { // Instantiation of Series objects
						seriesMatch =   line.substring(m).contains("Season")    ||
										line.substring(m).contains("Episode")   ||
										line.substring(m).contains("Volume")    ||
										line.substring(m).contains("Part")      ||
										line.substring(m).contains("Series")	  ||
										line.substring(m).contains("Collection")||
										line.substring(m).contains("Chapter")   ||
										line.substring(m).contains("Special")   ||
										line.substring(m).contains("Set");	
						
						movieMatch = line.substring(m).equals("m") || line.substring(m).equals("hr");
						if (m == 0 && !movieMatch && !seriesMatch) {
							makeMovieMatch = true;
							lengthSnatch = 0;
							seriesLengthType = "(NA)";
						}
							
					}
				
					if (seriesMatch) {
						seriesLengthType = line.substring(m);
						int seriesLengthEndIndex = m - 1;
						int v;
						for (v = seriesLengthEndIndex; line.charAt(v) == ' '; v--);
						lengthSnatch = Integer.parseInt(line.substring(v + 1, seriesLengthEndIndex));
						
					}
					else if (movieMatch) {
						
						if ((line.charAt(line.length() - 1) == 'm' && line.substring(line.length() - 5, line.length() - 3).contains("hr") || // line.charAt(line.length() - 4) == 'r') || // if we have hr and m
							(line.charAt(line.length() - 1) == 'm' && line.substring(line.length() - 6, line.length() - 4).contains("hr")))) { // line.charAt(line.length() - 5) == 'r')	) {
							int minuteSnatch;
							int g; //int counter = 0; 
							
							for (g = line.length() - 2; line.charAt(g) == ' '; g--); //{counter++}
							int minuteStartIndex = g + 1;
							minuteSnatch = Integer.parseInt(line.substring(minuteStartIndex, line.length() - 1));
							
							int hourSnatch;
							int hourBeginIndex; int hourEndIndex = g - 2;
							for (hourBeginIndex = g - 2; line.charAt(hourBeginIndex) == ' '; hourBeginIndex--);
							hourSnatch = Integer.parseInt(line.substring(hourBeginIndex + 1, hourEndIndex));
							
							lengthSnatch = (double) (hourSnatch + (double) (minuteSnatch / 60));
						}
						else if ((line.substring(line.length() - 2).contains("hr"))) { // if we have ONLY hr
							int hourSnatch;
							int hourBeginIndex; int hourEndIndex = line.length() - 2;
							for (hourBeginIndex = hourEndIndex; line.charAt(hourBeginIndex) == ' '; hourBeginIndex--);
							hourSnatch = Integer.parseInt(line.substring(hourBeginIndex + 1, hourEndIndex));
							
							lengthSnatch = (double) (hourSnatch);
						}
						else if ((line.charAt(line.length() - 1) == 'm' && !line.substring(line.length() - 5, line.length() - 3).contains("hr") || // if we have ONLY m
								 (line.charAt(line.length() - 1) == 'm' && !line.substring(line.length() - 6, line.length() - 4).contains("hr")))) {
							int minuteSnatch;
							int g; //int counter = 0; 
							
							for (g = line.length() - 2; line.charAt(g) == ' '; g--); //{counter++}
							int minuteStartIndex = g + 1;
							minuteSnatch = Integer.parseInt(line.substring(minuteStartIndex, line.length() - 1));
							
							lengthSnatch = (double) minuteSnatch;
						}
					}
//					else {
//					}
					
					if (seriesMatch) {
						masterList.add(new Series(titleSnatch, yearSnatch, ratingSnatch, lengthSnatch, seriesLengthType)); //= new ArrayList<Series>();
						}
					else {
						masterList.add(new Movie(titleSnatch, yearSnatch, ratingSnatch, lengthSnatch)); //= new Movie();
					}
		
			
				}
			}
	    	return masterList;    // Replace with the array that you return
	 }
	 
 
	 
	 	
	 public static void main(String[] args) {
		try {
			DataFileReader.readMediaData("C:\\Users\\casey\\Desktop\\NetflixUSA_Oct15_cleaned.txt");
		} catch (FileNotFoundException e) {
			System.out.println("File not found!");
			System.exit(1);
		}
		for (Media m : masterList) {
			System.out.println(m); 

		} 
		// System.out.println(masterList.get(10509));
	 } 
 }
	
