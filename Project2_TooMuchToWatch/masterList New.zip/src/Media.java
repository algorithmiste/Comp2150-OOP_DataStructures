
public abstract class Media {
	protected String title;
	protected int year;
	protected double rating;
	protected double length;
	
	public Media() {
		
	}
	
	public Media(String title, int year, double rating, double length) {
		this.title = title;
		this.year = year;
		this.rating = rating;
		this.length = length;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTitle() {
		return title;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getYear() {
		return year;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
	public double getRating() {
		return rating;
	}
	public void setLength(double length) {
		this.length = length;
	}
	public double getLength() {
		return length;
	}
	
	public String toString() {
		String toReturn = "This is media!";
		return toReturn;
		
	 }
}
